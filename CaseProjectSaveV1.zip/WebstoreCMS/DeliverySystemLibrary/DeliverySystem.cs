﻿using System.Net;
using System;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.UI.Services;
using System.Collections.Generic;

namespace DeliverySystemLibrary
{
    public class DeliverySystem
    {
        public void SendMessageTest()
        {
            string htmlMessage = ComposeMessage("Lennart", "nul,een,twee");
            string subject = ComposeSubject(1);
            SendEmailAsync("k4eede@hotmail.com", subject, htmlMessage);
        }

        public string ComposeMessage(string name, string productsOrderedString)
        {
            StringBuilder messageSb = new StringBuilder();
            messageSb.AppendLine($"Dear {name}");
            messageSb.AppendLine();
            messageSb.AppendLine("You have ordered the following products:");

            string[] productsOrdered = productsOrderedString.Split(',');
            foreach (var product in productsOrdered)
            {
                messageSb.Append("\t");
                messageSb.AppendLine($"{product}");
            }

            messageSb.AppendLine("Thank you and we hope to welcome you soon again.");
            messageSb.AppendLine("Regards:");
            messageSb.AppendLine("Wianne's Wizzarding Pony Paradise");
            messageSb.AppendLine();
            messageSb.AppendLine("This email has been automatically generated, replies will not be read");

            return messageSb.ToString();
        }

        public string ComposeSubject(int orderNumber)
        {
            return $"Confirmation for order: {orderNumber.ToString()}"; ;
        }

        public void SendEmailAsync(string email, string subject, string htmlMessage)
        {
            var client = new SmtpClient("smtp.gmail.com")
            {
                EnableSsl = true,
                Port = 587,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("ErikITPH@gmail.com", "knwlnzurhjbnyqnx")
            };
            var mailMessage = new MailMessage
            {
                From = new MailAddress("ErikITPH@gmail.com")
            };
            mailMessage.To.Add(email);
            mailMessage.Subject = subject;
            mailMessage.Body = htmlMessage;
            client.Send(mailMessage);
        }
    }
}