﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;
using ProductsManagementSystemLibrary;

namespace FinanceLibrary
{
    public class Order
    {
        //Properties
        public int Id { get; set; }
        [Required(ErrorMessage = " {0} must contain a valid ordernumber.")]
        public string OrderNumber { get; set; }
        [Required]
        [StringLength(1000, MinimumLength = 1)]
        public string OrderedProducts { get; set; }
        public bool Status { get; set; }
        [Required]
        public string TotalPrice { get; set; }
        public string StatusDescription { get; set; }
               
        public void Create(Guid orderNumber, List<Product> product)
        {
            Order order = new Order()
            {
                OrderNumber = orderNumber.ToString(),
                Status = true
            };
            
            foreach (var item in product)
            {
                OrderedProducts += (item.Name.Trim() + ", ");
            }
            OrderedProducts.Trim(',');
            StatusDescription = "This order is created";
        }

        public void Cancel()
        {
            Status = false;
            StatusDescription = "This order is canceled";
        }

    }
}
