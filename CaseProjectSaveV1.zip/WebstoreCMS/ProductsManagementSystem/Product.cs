﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductsManagementSystemLibrary
{

    public class Product
    {
        public int Id { get; set; }
        [Required]
        [StringLength(15, MinimumLength = 1)]
        public string Name { get; set; }
        [Required]
        [StringLength(20, MinimumLength = 1)]
        public string Price { get; set; }  
        [StringLength(500)]
        public string Description { get; set; }

        public int Stock { get; set; }
        public int Quantity { get; set; }
        public string Subtotal { get; set; }

        public bool InStock(int number)
        {
            return number <= this.Stock ? true : false;
        }

        public void GetSubtotal()
        {
            decimal.TryParse(Price, out decimal productPrice);
            Subtotal = ((Quantity * productPrice) / 100).ToString();
        }
    }
}
