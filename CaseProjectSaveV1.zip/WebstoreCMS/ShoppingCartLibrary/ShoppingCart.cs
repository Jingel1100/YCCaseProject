﻿using FinanceLibrary;
using ProductsManagementSystemLibrary;
using System;
using System.Collections.Generic;

namespace ShoppingCartLibrary
{
    public class ShoppingCart
    {
        public int Id { get; set; }
        public List<Product> Products { get; set; }
        public List<int> Quantities { get; set; }
        public string Total { get; set; }

        public ShoppingCart()
        {
            Products = new List<Product>();
            Quantities = new List<int>();
            Total = "0,00";
        }

        public void Add(Product product)
        {
            if (!this.Products.Contains(product))
            {
                this.Products.Add(product);
                this.Quantities.Add(1);
            }
            else
            {
                int index = this.Products.FindIndex(p => p==product);
                this.Quantities[index] += 1;
            }
        }

        public void Remove(Product product)
        {
            int index = this.Products.FindIndex(p => p == product);
            this.Quantities.RemoveAt(index);
            Products.Remove(product);

        }

        public void CalculateTotal()
        {
            decimal total = 0;
            foreach (var item in Products)
            {
                decimal.TryParse(item.Price, out decimal price);
                total += price;
            }

            Total = (total / 100).ToString();
        }

        public void ConfirmOrder()
        {
            foreach (var item in Products)
            {
                if (item.InStock(item.Quantity))
                {
                    item.Stock -= item.Quantity;
                }
                else
                {
                    Remove(item);
                }
            }
            Guid number = Guid.NewGuid();
            CalculateTotal();
            var order = new Order() { TotalPrice = Total };
            order.Create(number, Products);
        }



    }
}
