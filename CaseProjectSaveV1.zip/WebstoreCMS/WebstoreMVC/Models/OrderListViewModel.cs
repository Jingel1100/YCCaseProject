﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebstoreMVC.Models
{
    public class OrderListViewModel : ListViewModel<OrderListItemViewModel>
    {
        public int Id { get; set; }
        public int OrderNumber { get; set; }
        public decimal TotalPrice { get; set; }
        public bool Status { get; set; }
        public string StatusDescription { get; set; }

    }
}
