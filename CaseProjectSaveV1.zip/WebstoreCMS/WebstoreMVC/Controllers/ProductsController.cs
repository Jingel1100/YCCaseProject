﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using DeliverySystemLibrary;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductsManagementSystemLibrary;
using ShoppingCartLibrary;
using WebstoreMVC.Models;

namespace WebstoreMVC.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ProductManagementSystemDbContext _context;

        public ProductsController(ProductManagementSystemDbContext context)
        {
            _context = context;
        }

        // GET: Products
        public ActionResult Index(int pageNumber = 1)
        {
            var model = new ProductListViewModel();
            model.PageNumber = pageNumber;
            model.ListItems = _context.Products
                .OrderBy(p => p.Name)
                .Skip(model.PageSize * (model.PageNumber - 1))
                .Take(model.PageSize)
                .Select(p => new ProductListItemViewModel()
                {
                    Id = p.Id,
                    Name = p.Name,
                    Description = p.Description,
                    Stock=p.Stock,
                    Price = p.Price //p.Price.HasValue ? p.Price.Value.ToString() : "-"
                }).ToList();
            model.PageCount = (int)Math.Ceiling(_context.Products.Count() / (double)model.PageSize);
            model.AllowEdit = User.Identity.IsAuthenticated;

            return View(model);
        }

        // GET: Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .FirstOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
        [Authorize(Policy ="RequireStoreOwnerRole")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.

        [Authorize(Policy = "RequireStoreOwnerRole")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Price,Description,Stock")] Product product)
        {
            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        // GET: Products/Edit/5
        [Authorize(Policy = "RequireStoreOwnerRole")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Policy = "RequireStoreOwnerRole")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Price,Description,Stock")] Product product)
        {
            if (id != product.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        // GET: Products/Delete/5
        [Authorize(Policy = "RequireStoreOwnerRole")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .FirstOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Delete/5
        [Authorize(Policy = "RequireStoreOwnerRole")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.Id == id);
        }

        public async Task<IActionResult> Buy(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            //product.Quantity += 1;
            product.GetSubtotal();
            SaveItemToShoppingCart(product);
            return RedirectToAction(nameof(Index));
        }

        //SHOPPINGCART METHODS
        public ShoppingCart GetShoppingCart()
        {
            //try to get shoppingcart from cache otherwise create it. 

            if (!(this.HttpContext.Items["shoppingCart"] is ShoppingCart shoppingCart)) //!=
            {
                shoppingCart = new ShoppingCart();
            }

            return shoppingCart;
        }

        public void SaveItemToShoppingCart(Product product)
        {
            var shoppingCart = GetShoppingCart();
            shoppingCart.Add(product);
            shoppingCart.CalculateTotal();
            this.HttpContext.Items["shoppingCart"] = shoppingCart;
        }

        //Method ShoppingCart to Order.
        public void OrderShoppingCartItems()
        {
            var shoppingCart = GetShoppingCart();
            shoppingCart.ConfirmOrder();
            foreach (var product in shoppingCart.Products)
            {
               _context.Update(product);
               _context.SaveChanges();
               
            }
        }

        //Genenrate ShoppingCartView
        public ActionResult ShoppingCart()
        {
            var shoppingCart = GetShoppingCart();
            var model = new ShoppingCartListViewModel();
            model.Products = shoppingCart.Products.OrderBy(i => i.Name)
                .Select(i => new ProductListItemViewModel()
                {
                    Id = i.Id,
                    Name = i.Name,
                    Price = i.Price,
                    Stock = i.Stock,
                    Description = i.Description,
                    Quantity = i.Quantity.ToString(),
                    Subtotal = i.Subtotal
                }).ToList();
            model.Total = shoppingCart.Total;            

            return View("ShoppingCart", model);
        }

    }
}
