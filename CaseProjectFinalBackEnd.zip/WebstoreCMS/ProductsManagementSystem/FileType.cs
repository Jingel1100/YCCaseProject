﻿namespace ProductsManagementSystemLibrary
{
    public enum FileType
    {
        image = 1, Photo
    }
}